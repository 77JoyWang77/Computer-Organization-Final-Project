#ifndef __MEM_CACHE_REPLACEMENT_POLICIES_FREQUENCY_RP_HH__
#define __MEM_CACHE_REPLACEMENT_POLICIES_FREQUENCY_RP_HH__

#include "mem/cache/replacement_policies/base.hh"
#include "mem/cache/replacement_policies/replaceable_entry.hh"

class FrequencyRP : public BaseReplacementPolicy
{
  protected:
    class FrequencyReplData : public ReplacementData
    {
      public:
        int frequency;
        FrequencyReplData() : frequency(0) {}
    };

  public:
    FrequencyRP() = default;
    ~FrequencyRP() = default;

    std::shared_ptr<ReplacementData> instantiateEntry() override {
        return std::make_shared<FrequencyReplData>();
    }

    void touch(const std::shared_ptr<ReplacementData>& replacement_data) const override {
        auto freq_data = std::static_pointer_cast<FrequencyReplData>(replacement_data);
        freq_data->frequency++;
    }

    void reset(const std::shared_ptr<ReplacementData>& replacement_data) const override {
        auto freq_data = std::static_pointer_cast<FrequencyReplData>(replacement_data);
        freq_data->frequency = 0;
    }

    ReplaceableEntry* getVictim(const ReplacementCandidates& candidates) const override {
        assert(!candidates.empty());

        ReplaceableEntry* victim = candidates[0];
        int min_freq = std::static_pointer_cast<FrequencyReplData>(
                           victim->replacementData)->frequency;

        for (const auto& entry : candidates) {
            auto freq = std::static_pointer_cast<FrequencyReplData>(
                            entry->replacementData)->frequency;

            if (freq < min_freq) {
                min_freq = freq;
                victim = entry;
            }
        }

        return victim;
    }
};

#endif // __MEM_CACHE_REPLACEMENT_POLICIES_FREQUENCY_RP_HH__

